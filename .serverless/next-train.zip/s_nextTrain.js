
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ejzimmer',
  applicationName: 'next-train',
  appUid: 'lHbSqMbxj5rclm21Ln',
  orgUid: 'S0RmGWxQCSJYTNdk0W',
  deploymentUid: 'bc742c37-ad63-4a8b-962d-737b7b93ccdf',
  serviceName: 'next-train',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'next-train-dev-nextTrain', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.nextTrain, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}